repo: adithyachigullapally/SIH-BABU_BUGS-
branch: main

## Last sync
date: 2026-09-05T23:31:56Z

### Updated in this project
- Built `SatQuery AI.dc.html`: full frontend UI matching the exact `/api/health` and `/api/analyze` contract in `backend/main.py`, `backend/agent/controller.py`, `backend/agent/tool_schemas.py`.
- Tool names, confidence formula (0.85 base + deductions), and example queries sourced from `backend/agent/controller.py` and `frontend/index.html`.
- Overlay/mask URL handling matches `backend/main.py`'s `_to_url` (`/files/{job_id}/{name}`), with a fallback for absolute-path URLs.

## Screen map
| Project screen | Repo files |
| --- | --- |
| SatQuery AI.dc.html | backend/main.py, backend/agent/controller.py, backend/agent/tool_schemas.py, backend/validator.py, backend/tools/*.py, frontend/index.html |
